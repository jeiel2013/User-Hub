export type UsuariosDTO = {
    id?: number
    username: string
    email: string
    password: string
    name: string
    datacad?: Date
}